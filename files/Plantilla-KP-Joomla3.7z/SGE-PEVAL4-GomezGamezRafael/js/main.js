jQuery('#sidebar').hover(
    function(){ // Función de mousein
        jQuery(this).stop(true).animate({left:'-0.25%'});
    }, 
    function(){ // Función de mouseout
        jQuery(this).stop(true).animate({left:'-13%'});
    }
);
jQuery('#rightbar').hover(
    function(){ // Función de mousein
        jQuery(this).stop(true).animate({right:'-0.25%'});
    }, 
    function(){ // Función de mouseout
        jQuery(this).stop(true).animate({right:'-15%'});
    }
);

jQuery('a').hover(
        function(){ jQuery(this).stop(true).animate({color:'#FFD700'}, 250); },
        function(){ jQuery(this).stop(true).animate({color:'white'}, 250);   }
);
    
/*
$('#sidebar').hover(
    function(){ // Función de mousein
        $(this).stop(true).animate({left:'-0.25%'});
    }, 
    function(){ // Función de mouseout
        $(this).stop(true).animate({left:'-13%'});
    }
);
$('#rightbar').hover(
    function(){ // Función de mousein
        $(this).stop(true).animate({right:'-0.25%'});
    }, 
    function(){ // Función de mouseout
        $(this).stop(true).animate({right:'-15%'});
    }
);

$('a').hover(
        function(){ $(this).stop(true).animate({color:'#FFD700'}, 250); },
        function(){ $(this).stop(true).animate({color:'white'}, 250);   }
);
 * 
 * 
 */