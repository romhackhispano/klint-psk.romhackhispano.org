<?php

$doc = JFactory::getDocument();

$doc->addStyleSheet($this->baseurl . '/media/jui/css/bootstrap.min.css');
$doc->addStyleSheet('/joomla/templates/' . $this->template . '/css/styles.css');
$doc->addScript('/joomla/templates/' . $this->template . '/js/jquery-1.8.2.js');
$doc->addScript('/joomla/templates/' . $this->template . '/js/jquery.color.js');

?>
<!DOCTYPE html>
<html>
    <head>
        <jdoc:include type="head" />
    </head>
    <body>
        <div id="header">
        </div>
        <div id="menubarWrapper">
            <div id="menubar">
                <jdoc:include type="modules" name="position-1" style="well" />
            </div>
        </div>
        
    	<div id="sidebar"> 
            <span id="aux">
                <jdoc:include type="modules" name="sidebar" style="rounded"/>
            </span>
        </div>
        <div id="rightbar">
            <jdoc:include type="modules" name="rightbar" style="xhtml"/>
        </div>
        
    	<div id="content">
    	    <jdoc:include type="modules" name="content" style="xhtml"/>
            <jdoc:include type="component" />
            <jdoc:include type="message" />
        </div>
        <div id="foot">
            <jdoc:include type="modules" name="foot" style="xhtml"/>
        </div>
        <script src="<?php echo '/joomla/templates/' . $this->template . '/js/main.js';?>"></script>
    </body>
</html>